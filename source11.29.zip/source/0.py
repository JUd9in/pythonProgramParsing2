a=1
b=2
c=a+b
print(c)