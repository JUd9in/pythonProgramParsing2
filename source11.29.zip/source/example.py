a = 1
b = 2
c = a + b
d = c - 1 + a
print(c)
print(a, b, c)
